#include <stdio.h>
#include "info.h"

void test(struct info_t *info)
{
	printf("Hello, DL!\n");
}
