사용법
1. dl을 관리하는 폴더를 만든다.
2. dl.rc를 참고하여 rc 파일을 만든다.
3. dl.rc를 만든 폴더에 위치한다.
   $ mv dl.rc /etc/3team
4. make
5. ./module-manager <options>
