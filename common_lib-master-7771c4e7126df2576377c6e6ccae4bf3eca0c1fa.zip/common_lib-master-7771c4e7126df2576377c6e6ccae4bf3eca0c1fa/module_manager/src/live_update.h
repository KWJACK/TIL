#ifndef LIVE_UPDATE_H
#define LIVE_UPDATE_H

#include "tcp_client.h"
#include "../parson/parson.h"

void* live_update_check_cb(struct info_t *info);

#endif
