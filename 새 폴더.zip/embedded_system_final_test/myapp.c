// 라즈베리 파이에서 빌드하세요.
// # gcc myapp.c -o myapp -lwiringPi
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include <mcp3422.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>

#define LED_RATIO _IOW('c', 1, int)

int main(int argc, char* argv[])
{
    int fd = open("/dev/mydev", O_RDWR);
    if (fd == -1) {
        perror("open");
        return -1;
    }

    wiringPiSetup();
    pinMode(26, PWM_OUTPUT);
    mcp3422Setup(400, 0x6a, 0, 0);
    for (;;) {
        int cds = analogRead(400);
        printf("%4d\n", cds);
        ioctl(fd, LED_RATIO, &cds);
        delay(100);
    }

    close(fd);
}
