
#include <stdio.h>

int main() {
	printf("%lu\n", sizeof(int));
	return 0;
}
