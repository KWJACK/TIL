
// 사번과 이름을 적으시오.
// 사번: 79548
// 이름: 이재근	

#include <sys/time.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#define err_abort(code,text) do {       					\
	fprintf(stderr, "%s at \"%s\":%d: %s\n",  			\
			text, __FILE__, __LINE__, strerror(code));  \
	abort();    																		\
}while(0)

#define errno_abort(text) do {       								\
	fprintf(stderr, "%s at \"%s\":%d: %s\n",  				\
			text, __FILE__, __LINE__, strerror(errno));		\
	abort();    																			\
} while(0)

typedef struct alarm_tag {
	struct alarm_tag    *next;
	int                 seconds;
	time_t              time;   /* seconds from EPOCH */
	char                message[64];
} alarm_t;

pthread_mutex_t alarm_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t alarm_cond = PTHREAD_COND_INITIALIZER;
alarm_t *alarm_list=NULL;

// 전역 변수는 최대 2개까지 추가 가능합니다.

// 아래의 함수를 구현하세요.
void display_list() {
	if(alarm_list==NULL){
		printf("[no alarm]\n");
		return;
	}

	alarm_t* temp = alarm_list;
	while(temp!=NULL)
	{
		printf("seconds :%d, mesg : %s\n",
				temp->seconds, temp->message);
		temp= temp->next;
	}
}

// 아래의 함수를 구현하세요.
void alarm_insert (alarm_t *alarm){
	if(alarm_list==NULL){
		alarm_list = alarm;
		return;
	}
	if(alarm_list->seconds > alarm->seconds){
		alarm->next = alarm_list;
		alarm_list = alarm;
		return;
	}

	alarm_t* temp = alarm_list;
	alarm_t* temp_next = temp->next;
	
	while(temp!=NULL){
		if(temp_next == NULL){
			if(temp->seconds < alarm->seconds){
				temp->next = alarm;
				return;
			}	
		}
		else{
			if(temp->seconds < alarm->seconds &&
					temp_next->seconds > alarm->seconds){
				alarm->next = temp_next;
				temp->next = alarm;
				return;
			}
			temp = temp->next;
			temp_next = temp_next->next;
		}
	}
}

void alarm_subtract(){
		printf("%s\n", alarm_list->message);	
		alarm_t* temp = alarm_list;
		alarm_t* prev = alarm_list;
		if(alarm_list != NULL)	
			alarm_list  = temp->next;

	
}
void *alarm_thread (void *arg) {
	signal(SIGALRM, alarm_subtract);

	int status = pthread_mutex_lock (&alarm_mutex);
	if (status != 0)
		err_abort (status, "Lock mutex");
	int now_alarm =0;
	while (1) {
		if(alarm_list==NULL){
			pthread_cond_wait(&alarm_cond, &alarm_mutex);
		}
		else{
			
			// 나머지를 구현하세요.
			struct timeval now;
			struct timespec ts;
			gettimeofday(&now, NULL);
			
			ts.tv_sec = now.tv_sec + alarm_list->seconds;
			
			pthread_cond_timedwait(&alarm_cond, &alarm_mutex, &ts);
			alarm(alarm_list->seconds);
			
		}
	}
	pthread_mutex_unlock(&alarm_mutex);
	return NULL;
}

int main() {
	pthread_t thread;
	int status = pthread_create(&thread, NULL, alarm_thread, NULL);
	if (status != 0)
		err_abort (status, "Create alarm thread");
	int i=0;
	char *sep = " \n";
	char *token;
	while (1) {
		printf("Alarm> ");

		char line[128];
		if (fgets(line, sizeof (line), stdin) == NULL)
			exit (0);
		
		if (strlen(line) <= 1)
			continue;

		if (strncmp(line, "list", 4) == 0) {
			display_list();
			continue;
		}

		// 이곳에서 알람 생성 및 리스트 추가 그리고 시그널 전송 코드를
		// 구현합니다.
		pthread_mutex_lock(&alarm_mutex);
		if(strlen(line) >2 ){
			alarm_t *node = malloc(sizeof(alarm_t));
			node->next = NULL;
			
			token = strtok(line, sep);
			node->seconds = atoi(token);
			token = strtok(NULL, sep);
			strcpy(node->message, token);
			alarm_insert(node);
		}
		pthread_cond_signal(&alarm_cond);
		pthread_mutex_unlock(&alarm_mutex);
	}
}
