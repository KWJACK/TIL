#include <stdio.h>

// protocol 
// tcphdr
// iphdr

struct AAA
{
	int bit:1;
};
