#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

int my_system(char *command){
	pid_t pid = fork();
	if(pid==0){
		execl("/bin/sh", "sh", "-c", command, (char *) 0);
		_exit(127);
	}
	else if(pid<0){
		perror("error!");
	}
	
	return waitpid(pid, 0, 0);
}

int main(){
	my_system("ls -l");
	printf("after\n");
	return 0;
}

