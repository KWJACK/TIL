#include <stdio.h>
int main() 
{
	char ch = 250;
	printf("%d\n", ch );
}

