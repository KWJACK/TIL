#include <stdio.h>
#include <unistd.h>

#define STDIN 0
#define STDOUT 1
#define STDERR 2

int main(){
	char buff[4096];
	while(1){
		int nread = read(STDIN, buff, sizeof buff);
		if(nread<=0)return -1;

		write(STDOUT, buff, nread);//nread : 실제 읽은 갯수
	}
	return 0;
}
#if 0
// 9systemcall.c
#include <stdio.h>

// 종료를 하려면 현재 프로그램에 EOF를 전송하면 됩니다.
// 전송 방법: CTRL + D	(# stty -a)
int main() {
	char buff[4096];
	while (1) {
		if (fgets(buff, sizeof buff, stdin) == NULL)
			return -1;
		fputs(buff, stdout);
	}
	return 0;
}
#endif
