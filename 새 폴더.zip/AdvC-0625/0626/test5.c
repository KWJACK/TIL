
void foo(void* a)
{

}

int main()
{
	int* p;
	double* a;
	char* c;

	foo(p);
	foo(a);
	foo(c);
}
