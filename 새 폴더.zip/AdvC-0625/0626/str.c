
#include <stdio.h>
#include <string.h>

int main()
{
	char* s = "한글";
	int len = strlen(s);

	printf("len: %d\n", len);
}
