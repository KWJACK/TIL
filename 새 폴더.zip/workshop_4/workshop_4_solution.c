#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/workqueue.h>
#include <linux/gpio.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/wait.h>

#define PIN  5 

static DECLARE_WAIT_QUEUE_HEAD(my_wait);
static int scale [8] = { 262, 294, 330, 349, 392, 440, 494, 525 } ;
static int freqs;

static struct task_struct *play_thread = NULL;
static struct work_struct my_work;
static int irq;

void softToneWrite (int pin, int freq)
{
	pin &= 63 ;

	if (freq < 0)
		freq = 0 ;
	else if (freq > 5000) // Max 5KHz
		freq = 5000 ;

	freqs = freq ;
}

irqreturn_t my_irq_handler(int irq, void *id)
{
	printk("my_irq_handler(%d, %p)\n", irq, id );
	schedule_work(&my_work);
	return IRQ_HANDLED;
}

void my_work_handler(struct work_struct *work)
{
	int i;
	printk("my_work_handler(%p)\n", work );
	wake_up_interruptible(&my_wait);
	for (i = 0 ; i < 8 ; ++i)
	{
		printk ("%3d\n", i) ;
		softToneWrite (PIN, scale [i]) ;
		mdelay (500) ;
	}
	freqs=0;
}

static int my_play_thread (void *data)
{
	int halfPeriod ;
	printk("my_play_thread start(%p)\n", data );
	do 
	{
		wait_event_interruptible(my_wait, freqs!=0);
		if( freqs != 0 )
		{
			halfPeriod = 500000 / freqs ;

			gpio_set_value (PIN, 1) ;
			udelay(halfPeriod) ;

			gpio_set_value (PIN, 0) ;
			udelay(halfPeriod) ;
		}
		mdelay(1);
	} while (!kthread_should_stop ());   
	return 0;
}

int my_init(void)
{
	unsigned long flags=0x81;
	int ret;
	freqs=0;
	printk("my_init()\n");
    play_thread = kthread_run (my_play_thread, NULL, "my_play_thread"); 
	INIT_WORK( &my_work, my_work_handler);
	gpio_direction_input(23);
	gpio_direction_output(PIN,0);
	irq = gpio_to_irq(23);
	ret=request_irq(irq, my_irq_handler, flags, "MY INT 1", (void *)0x1234);
	return 0;
}

void my_exit(void)
{
	printk("my_exit()\n");
	freqs=1;
	wake_up_interruptible(&my_wait);
	kthread_stop (play_thread);   
	free_irq(irq, (void *)0x1234);
}

module_init(my_init);
module_exit(my_exit);
MODULE_LICENSE("GPL");
