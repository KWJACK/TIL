var mongoose = require('mongoose');
var enevSchema = mongoose.Schema({
    "Temperature":   Number,
    "Humidity": Number,
    "Lux": Number,
    "date": { type: Date, default: Date.now , unique: true}
}, {versionKey: false}/*__v버전키 필드 제거*/);
module.exports = mongoose.model('enev', enevSchema);
