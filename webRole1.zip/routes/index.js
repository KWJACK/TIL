var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.ejs');
});

router.get('/flot', function(req, res, next) {
  res.render('flot.ejs');
});

module.exports = router;
