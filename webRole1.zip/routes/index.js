var express = require('express');
var net = require('net');
var mongoose = require('mongoose');

var router = express.Router();


mongoose.connect('mongodb://localhost:27017/testDB');
var db = mongoose.connection;
db.on('error', function(){
    console.log('Connection Failed!');
});
db.once('open', function() {
    console.log('MongoDB Connected!');
});

var Enev = require('./model/Enev.js');

// var newEnev = new Enev({
//     "Temperature": "25",
//     "Humidity": "40"
//   });
//
// newEnev.save(function(error, data){
//     if(error){
//         console.log(error);
//     }else{
//         console.log('Saved!');
//     }
// });

/* GET home page. */
router.get('/', function(req, res, next) {
  Enev.find({}, null, {sort: {"date":-1}}, function(err,docs){
    //ㄴcondition, columns to return, sort, function
    // console.log(docs);
    res.render('index.ejs', {docs: docs});
  });
});

router.get('/flot', function(req, res, next) {
  res.render('flot.ejs');
});

router.get('/tables', function(req, res, next) {
  res.render('tables.ejs');
});

router.get('/blank', function(req, res, next) {
  res.render('blank.ejs');
});

router.get('/login', function(req, res, next) {
  res.render('login.ejs');
});

router.get('/admin', function(req, res, next) {
  res.render('admin.ejs');
});



module.exports = router;
